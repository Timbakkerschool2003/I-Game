<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tags bevatten informatie over de tekenset en viewport-instellingen -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- De titel van de webpagina -->
    <title>Game Results</title>
    
    <!-- Koppeling naar het externe CSS-bestand voor opmaak van de pagina -->
    <link href="../../css/app.css" rel="stylesheet">
</head>
<body>
    <!-- Container voor de gehele inhoud van de pagina -->
    <div class="container">
        
        <!-- Titel van de pagina -->
        <h2>Game Over - Resultaten</h2>
        
        <!-- Tabel om de resultaten van het spel weer te geven -->
        <table class="results-table">
            <!-- Tabelkop met de kolomnamen -->
            <thead>
                <tr>
                    <th>Week</th>
                    <th>Extra Order</th>
                    <th>Customer Orders</th>
                    <th>Backorder</th>
                    <th>Costs</th>
                    <th>Incoming Delivery</th>
                    <th>Inventory</th>
                    <th>Outgoing Delivery</th>
                </tr>
            </thead>
            <!-- Tabellichaam met de gegevens -->
            <tbody>
                <!-- Loop door de resultaten om elke rij in de tabel te genereren -->
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <!-- Toon de weeknummer -->
                        <td><?php echo e($result['week']); ?></td>
                        <!-- Toon de extra bestellingen -->
                        <td><?php echo e($result['extra_order']); ?></td>
                        <!-- Toon de klantbestellingen -->
                        <td><?php echo e($result['customer_orders']); ?></td>
                        <!-- Toon de achterstanden, en maak de cel rood als de waarde groter is dan 500 -->
                        <td class="<?php echo e($result['backorder'] > 500 ? 'red' : ''); ?>"><?php echo e($result['backorder']); ?></td>
                        <!-- Toon de kosten -->
                        <td><?php echo e($result['costs']); ?> €</td>
                        <!-- Toon de inkomende leveringen -->
                        <td><?php echo e($result['incoming_delivery']); ?></td>
                        <!-- Toon de voorraad -->
                        <td><?php echo e($result['inventory']); ?></td>
                        <!-- Toon de uitgaande leveringen -->
                        <td><?php echo e($result['outgoing_delivery']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <!-- Formulier om het spel te resetten en terug te gaan naar de beginpagina -->
        <form action="<?php echo e(route('igame.reset')); ?>" method="POST">
            <!-- CSRF-token voor beveiliging van het formulier -->
            <?php echo csrf_field(); ?>
            <!-- Knop om het formulier in te dienen -->
            <button type="submit" class="back-button">Terug naar Beginpagina</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Timba\Documents\GitHub\I-Game\iGame\resources\views/results.blade.php ENDPATH**/ ?>